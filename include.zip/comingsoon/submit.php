<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "popmedi2_WP5DL", "vi1u1IRFwMlm3jWKM", "popmedi2_WP5DL");
 
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$website = mysqli_real_escape_string($link, $_REQUEST['website']);
$email = mysqli_real_escape_string($link, $_REQUEST['email']);
 
// Attempt insert query execution
$sql = "INSERT INTO subscribe (name, website, email) VALUES ('$name', '$website', '$email')";
if(mysqli_query($link, $sql)){
    header("Location: http://cwnsports.com/comingsoon/");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($lnk);
}
 
// Close connection
mysqli_close($link);

?>